import React, { Component } from 'react'

export default class Classc1 extends Component {
  render() {
    return (
      <div>
        <h2>jjjjjjjjj</h2>
      </div>
    )
  }
}
