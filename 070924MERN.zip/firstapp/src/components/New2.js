import React from 'react'

function New2() {
  return (
    <div>
      <h2>PAtticheee</h2>
    </div>
  )
}

export default New2
