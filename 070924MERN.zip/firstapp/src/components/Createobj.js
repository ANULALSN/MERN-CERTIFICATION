import React from 'react'

function Createobj() {

    var employee={
name:"Riya",
dept:"CS",
place:"Calicut"

    };
  return (
    <div>
      <h1>Employee Details</h1>
      <p>name:{employee.name}</p>
      <p>dept:{employee.dept}</p>
      <p>place:{employee.place}</p>
    </div>
  )
}

export default Createobj
