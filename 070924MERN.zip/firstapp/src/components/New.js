import React from 'react'
import Classc1 from './Classc1'


function New(){
return (
    <div>
<h1>hiroshima Nagasaki</h1>
<Classc1></Classc1>
    </div>
)

}
export default New