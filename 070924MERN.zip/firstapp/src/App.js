import logo from './logo.svg';
import './App.css';
import New from './components/New';
import New2 from './components/New2';
import Createobj from './components/Createobj';

function App() {
  let a=10;
  let b=20;
  function addnum(){
    return `${a}+${b}=${a+b}`
  }
  return (
    <div className="App">
  
       <h1>Hello world</h1>
       <h2>{addnum()}</h2>
       <New> </New>
       <New2> </New2>
   
      <Createobj/>
      
    </div>
  );
}

export default App;
