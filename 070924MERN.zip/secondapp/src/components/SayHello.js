import React from 'react'
import Button from 'react-bootstrap/Button'
import 'bootstrap/dist/css/bootstrap.min.css';

function SayHello() {
 function SayHello1(){
    alert('Poyi pani nokkedaa');
 }
 return (
    <button onClick={SayHello1}>Onn Njekikkeee</button>
    
 );

}


export default SayHello
