import React from 'react'

function Mymap() {
    const people=[
{id:1,name:"Rashid",gender:"Male",age:40},
{id:2,name:"Gokul",gender:"Male",age:25},
{id:3,name:"Asher",gender:"Male",age:34},
{id:4,name:"Ayush",gender:"Male",age:38},
{id:5,name:"Sainadh",gender:"Male",age:17},
]
  return (
    <div>
      {people.map(person=>{
        return (
            <h4> 
                <h1><b>Name:{person.name}</b></h1>
                <p>Id :{person.id}</p>
                <p>Age :{person.age}</p>
                <p>Gender :{person.gender}</p>

            </h4>
        )
      })}
    </div>
  )
}

export default Mymap
