import React from 'react'

function SimpleMap() {
    const array1=[1,4,9,16];

    const map1=array1.map((x)=>x*2);
    console.log(map1)
  return (
    <>
      <h1>{map1}</h1>
    </>
  )
}

export default SimpleMap
