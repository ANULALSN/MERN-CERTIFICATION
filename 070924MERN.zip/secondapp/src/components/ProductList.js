const Products=[
    {id:1,
        name:"Dhasamoolam",
        description:"High power item",
        imageUrl:"dhasamoolam.jpeg"

    },
    {id:2,
        name:"Idivettu ",
        description:"high power and voltage",
        imageUrl:"idivettu.jpeg"

    },
    {id:3,
        name:"Minnal murali",
        description:"Equalent to idivettu",
        imageUrl:"minnal.jpeg"

    }
];
export default Products;