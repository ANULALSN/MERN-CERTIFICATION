import React from 'react'
import Spinner from 'react-bootstrap/Spinner';

function Loader() {
  return (
    <div>
       <Spinner animation="border" variant="primary" />
       <Spinner animation="grow" variant="primary" />
      <Spinner animation="border" variant="secondary" />
      <Spinner animation="border" variant="success" />
      <Spinner animation="grow" variant="secondary" />
      <Spinner animation="border" variant="danger" />
      <Spinner animation="border" variant="warning" />
      <Spinner animation="border" variant="info" />
      <Spinner animation="border" variant="light" />
      <Spinner animation="border" variant="dark" />
     
     
    </div>
  )
}

export default Loader
