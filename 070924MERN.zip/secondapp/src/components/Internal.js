import React from 'react'

function Internal() {
    const mystyle={backgroundColor:"blue"}
    const mystyle1={backgroundColor:"pink"}
    const mystyle2={backgroundColor:"yellow"}
  return (
    <React.Fragment>
      <p style={mystyle}>blue color through internal css</p>
      <h4 style={mystyle1}>pink color through internal css</h4>
      <h3 style={mystyle2}>yellow color through internal css</h3>
    </React.Fragment>
  )
}

export default Internal
