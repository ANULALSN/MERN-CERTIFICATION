import React from 'react'
import './External.css'

function Child(props) {
    const {name,color,petals}=props.flower;
  return (
    <div>
      <h2 className='p1'>Child component</h2>
      <p className='a1'>Flower name:{name}</p>
      <p className='a1'>Color:{color}</p>
      <p >Petals:{petals}</p>
    </div>
  )
}

export default Child
