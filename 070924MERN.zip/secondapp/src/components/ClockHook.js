import React, { useEffect, useState } from 'react'

function ClockHook() {
    const[date ,setDate]=useState(new Date())
    function newclock(){
        setDate(new Date());
    }
    useEffect(()=>{
        setInterval(newclock,1000)//1000 means 1 second
    })

  return (
    <div>
           <h1>{date.toLocaleTimeString()}</h1>  
    </div>
  )
}

export default ClockHook
