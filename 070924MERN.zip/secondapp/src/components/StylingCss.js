import React from 'react'

function StylingCss() {
  return (
    <div>StylingCss
        <h1 style={{color:'red'}}>heading content

    </h1>
      
    </div>
  )
}

export default StylingCss
