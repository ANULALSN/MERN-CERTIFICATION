import logo from './logo.svg';
import './App.css';
import SimpleMap from './components/SimpleMap';
import Parent from './components/Parent';
import Mymap from './components/Mymap';
import StylingCss from './components/StylingCss';
import Internal from './components/Internal';
import Componentboots from './components/Componentboots';
import Accordion1 from './components/Accordion1';
import Car1 from './components/Car1';
import ProductList1 from './components/ProductList1';
import Loader from './components/Loader';
import SayHello from './components/SayHello';
import HooksMycount from './components/HooksMycount';
import HooksUseEffect from './components/HooksUseEffect';
import ClockHook from './components/ClockHook';
import Todo from './components/Todo';


function App() {
  return (
    <div className="App">
      
      <SimpleMap> </SimpleMap>
      <Parent> </Parent>
      <Mymap/>
      <StylingCss/>
      <Internal/>
      <Componentboots> </Componentboots>
      <Accordion1></Accordion1>
      <Car1></Car1>
     <ProductList1> </ProductList1>
     <Loader></Loader>
     <SayHello></SayHello>
     <HooksMycount></HooksMycount>
     <HooksUseEffect></HooksUseEffect>
     <ClockHook></ClockHook>
     <Todo></Todo>
    </div>
  );
}

export default App;
